import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import QRCodeComponent from '../components/QRCodeComponent';

const Profile = () => {
const { userId } = useParams();
const [user, setUser] = useState(null);

useEffect(() => {
    fetch(`/api/users/${userId}`)
    .then((response) => response.json())
    .then((data) => setUser(data))
    .catch((error) => console.error(error));
}, [userId]);
return (
<div>
    {user ? (
    <div>
        <h1>{user.name}</h1>
        <p>{user.email}</p>
        <img src={user.profilePhoto} alt="Profile" />
        <QRCodeComponent userId={userId} />
    </div>
    ) : (
    <p>Loading...</p>
    )}
</div>
);
};

export default Profile;