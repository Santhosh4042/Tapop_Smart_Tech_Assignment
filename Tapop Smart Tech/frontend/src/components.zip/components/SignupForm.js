import React, { useState } from 'react';
import { auth, googleProvider } from '../firebase';
import { useHistory } from 'react-router-dom';

const SignupForm = () => {
    const [formData, setFormData] = useState({
    name: '',
    phoneNumber: '',
    email: '',
    password: '',
    profilePhoto: '',
    coverPhoto: ''
});
const history = useHistory();

const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
};

const handleSignup = async (e) => {
    e.preventDefault();
    try {
        const userCredential = await auth.createUserWithEmailAndPassword(formData.email, formData.password);
        const user = userCredential.user;
        await user.updateProfile({
            displayName: formData.name,
            photoURL: formData.profilePhoto
        });
      // Save additional user info to your database
    history.push('/profile');
    } catch (error) {
        console.error(error);
    }
};

const handleGoogleSignup = async () => {
    try {
        await auth.signInWithPopup(googleProvider);
        history.push('/profile');
    } catch (error) {
        console.error(error);
    }
};

return (
    <form onSubmit={handleSignup} className="space-y-4">
        <input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="Name" className="input" required />
        <input type="tel" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} placeholder="Phone Number" className="input" required />
        <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Email" className="input" required />
        <input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Password" className="input" required />
        <input type="text" name="profilePhoto" value={formData.profilePhoto} onChange={handleChange} placeholder="Profile Photo URL" className="input" />
        <input type="text" name="coverPhoto" value={formData.coverPhoto} onChange={handleChange} placeholder="Cover Photo URL" className="input" />
        <button type="submit" className="btn">Sign Up</button>
        <button type="button" onClick={handleGoogleSignup} className="btn">Sign Up with Google</button>
    </form>
);
};

export default SignupForm;