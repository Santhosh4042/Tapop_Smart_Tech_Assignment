import React from 'react';
import './InteractiveImage.css'; // Ensure you have the appropriate CSS

const InteractiveImage = ({ src }) => {
    const handleMouseMove = (e) => {
    const { target } = e;
    const rect = target.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    target.style.transform = `translate(${(x - rect.width / 2) / 10}px, ${(y - rect.height / 2) / 10}px)`;
};

return <img src={src} alt="Interactive" className="interactive-image" onMouseMove={handleMouseMove} />;
};

export default InteractiveImage;