import React from 'react';
import QRCode from 'qrcode.react';

const QRCodeComponent = ({ '#' }) => {
const profileUrl = `${window.location.origin}/profile/${userId}`;

return (
    <div>
    <QRCode value={profileUrl} />
    </div>
);
};

export default QRCodeComponent;